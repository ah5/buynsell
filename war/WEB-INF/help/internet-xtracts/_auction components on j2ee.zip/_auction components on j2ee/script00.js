foo = new Array()
for (i = 0; i < 32; i ++) {
foo[i] = new Image()
}

foo[0].src = "../../images/pics/terry_on.gif"
foo[1].src = "../../images/pics/terry_off.gif"
foo[2].src = "../../images/pics/sandy_on.gif"
foo[3].src = "../../images/pics/sandy_off.gif"
foo[4].src = "../../images/pics/kyle_on.gif"
foo[5].src = "../../images/pics/kyle_off.gif"
foo[6].src = "../../images/pics/jimC.gif"
foo[7].src = "../../images/pics/jimC_off.gif"
foo[8].src = "../../images/pics/jimR_on.gif"
foo[9].src = "../../images/pics/jimR_off.gif"
foo[10].src = "../../images/pics/gail_on.gif"
foo[11].src = "../../images/pics/gail_off.gif"
foo[12].src = "../../images/pics/maxine_on.gif"
foo[13].src = "../../images/pics/maxine_off.gif"
foo[14].src = "../../images/pics/michele_on.gif"
foo[15].src = "../../images/pics/michele_off.gif"
foo[16].src = "../../images/pics/top_on.gif"
foo[17].src = "../../images/pics/top_off.gif"
foo[18].src = "../../images/pics/excellence_on.gif"
foo[19].src = "../../images/pics/excellence_off.gif"
foo[20].src = "../../images/pics/experience_on.gif"
foo[21].src = "../../images/pics/experience_off.gif"
foo[22].src = "../../images/pics/collaboration_on.gif"
foo[23].src = "../../images/pics/collaboration_off.gif"
foo[24].src = "../../images/pics/speed_on.gif"
foo[25].src = "../../images/pics/speed_off.gif"
foo[26].src = "../../images/pics/reliability_on.gif"
foo[27].src = "../../images/pics/reliability_off.gif"
foo[28].src = "../../images/pics/index_on.gif"
foo[29].src = "../../images/pics/index_off.gif"
foo[30].src = "../../images/pics/back_on.gif"
foo[31].src = "../../images/pics/back_off.gif"

function over(i) {
imagename = "../../images/pics/" + i + "_on.gif"
document.images[i].src = imagename
return true;
}
function out(i) {
imagename = "../../images/pics/" + i + "_off.gif"
document.images[i].src = imagename
return true;
}

function Launch(theURL,winName,features) {
  sw=screen.availWidth;
  sh=screen.availHeight;
  posLeft=(sw-700)/2;
  posTop=(sh-540)/2;
  window.open(theURL,'project','width=700,height=540,scrollbars=yes,left='+posLeft+',top='+posTop);
}


function Launch(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}

function LaunchB(theURL,winName,features) {
  sw=screen.availWidth;
  sh=screen.availHeight;
  posLeft=(sw-380)/2;
  posTop=(sh-400)/2;
  window.open(theURL,'new','scrollbars=yes,width=380,height=400,left='+posLeft+',top='+posTop);
}


function LaunchT(theURL,winName,features) {
  sw=screen.availWidth;
  sh=screen.availHeight;
  posLeft=(sw-380)/2;
  posTop=(sh-268)/2;
  window.open(theURL,'new','scrollbars=yes,width=380,height=268,left='+posLeft+',top='+posTop);
}

function LaunchJ(theURL,winName,features) {
  sw=screen.availWidth;
  sh=screen.availHeight;
  posLeft=(sw-380)/2;
  posTop=(sh-350)/2;
  window.open(theURL,'new','scrollbars=yes,width=380,height=350,left='+posLeft+',top='+posTop);
}

function LaunchN(theURL,winName,features) {
  sw=screen.availWidth;
  sh=screen.availHeight;
  posLeft=(sw-380)/2;
  posTop=(sh-380)/2;
  window.open(theURL,'new','scrollbars=yes,width=380,height=380,left='+posLeft+',top='+posTop);
}

function LaunchP(theURL,winName,features) {
  sw=screen.availWidth;
  sh=screen.availHeight;
  window.open(theURL,'new','scrollbars=yes,status=yes,toolbar=yes,resizable=yes');
}

function LaunchI(theURL,winName,features) {
  sw=screen.availWidth;
  sh=screen.availHeight;
  posLeft=(sw-720)/2;
  posTop=(sh-480)/2;
  window.open(theURL,'new','scrollbars=no,width=720,height=480,left='+posLeft+',top='+posTop);
}

function Check() {
  theWin=window.parent.name;
  if (theWin == 'new') {
    window.parent.close();
  } else {
    window.parent.location="http://www.omix.com";
  }
}

function Check2() {
  theWin=parent.name;
  if (theWin == 'new') {
    parent.opener.parent.main.location='../about/signup.html';
    parent.close();
  } else {
    parent.location='http://www.omix.com/main2.html';
  }
}

function Check3() {
  theWin=parent.name;
  if (theWin == 'new') {
    parent.opener.parent.main.location='../home.html';
    parent.close();
  } else {
    parent.location='http://www.omix.com';
  }
}


if (navigator.appName == "Netscape") {
  var layerRef="document.layers";
  var styleSwitch="";
}else{
  var layerRef="document.all";
  var styleSwitch=".style";
}

function showLayer(layerName) {
  eval(layerRef+'["'+layerName+'"]'+styleSwitch+'.visibility="visible"');
}

function hideLayer(layerName) {
  eval(layerRef+'["'+layerName+'"]'+styleSwitch+'.visibility="hidden"');
}