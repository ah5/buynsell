var expHours = 4; // number of hours the cookie should last

var fromurl = document.referrer;
var visitedurl = document.location.href;

function baazeeNaturalSearch()
{
	var aEngines=new Array("search.yahoo.com","search.msn.",".altavista.com","suche.lycos.at","www.google.at","search.aon.at/newsearch/aon/","austronaut.at/page.php","www.google.com.au","images.google.com.au","www.looksmart.com.au","ninemsn.com.au","search.aol.com.au","www.goeureka.com.au","au.anzwers.yahoo.com","www.yellowpages.com.au/search/searchEntry.do","search.bigpond.com","www.google.be","search.fr.msn.be","altavista.advalvas.be/av2/","yellow.advalvas.be/av2/scripts/YellowSearch.dll","www.google.ca","ca.yahoo.com","www.toile.qc.ca","www.alltheweb.com","www.overture.com/d/search/p/altavista/odp/ca/","www.lycos.ca","search.lycos.com/default.asp","www.looksmart.com","search.bluewin.ch/bw/search/web/de/home.html","www.search.ch","www.google.ch","www.google.com","images.google.com","directory.google.com","www.baidu.com/","image.baidu.com/","site.baidu.com/","cns.3721.com/","seek.3721.com/","page.zhongsou.com/","hc360.zhongsou.com/","site.zhongsou.com/","search.sina.com.cn/","pic.sina.com.cn/","dir.sina.com.cn/","search.sohu.com/","image.search.sohu.com/","www.sogou.com/","nisearch.163.com/","psearch.163.com/","picsearch.163.com/","search.tom.com/","sitesearch.tom.com/","cn.websearch.yahoo.com/","cn.imagesearch.yahoo.com/","www.yisou.com/search","image.yisou.com/","www.8848.com/search.dll","www.google.de/search","images.google.de/images","suche.aol.de/suche/","suche.aol.de/shopping/suche/index.jsp","suche.freenet.de/suche","shopping.freenet.de/suchergebnis/index.html","brisbane.t-online.de/fast-cgi/tsc","shopping1.t-online.de/toi/scripts/query.php","suche.web.de/search/","dir.web.de","suche.lycos.de","webkatalog.lycos.de","www.google.es","images.google.es","buscador.terra.es","buscar.ya.com","www2.yatv.com","busca.wanadoo.es/search","www.google.fr","images.google.fr","www.recherche.aol.fr","www.images.aol.fr","vachercher.lycos.fr/cgi-bin/pursuit","rechercher.nomade.tiscali.fr/recherche.asp","search.ke.voila.fr","recherche.wanadoo.fr","search1-2.free.fr","www.overture.com/d/search/p/altavista","www.google.it","search.virgilio.it","arianna.libero.it","business.libero.it/arianna/","search.tiscali.it","www.google.nl","www.ilse.nl/searchresults.dbl","pagina.nl","tw.yahoo.com","www.google.com.tw","images.google.com.tw","www.pchome.com.tw","image.pchome.com.tw","dir.pchome.com.tw","www.yam.com","wps.yam.com","dir.yam.com","www.msn.com.tw","www.google.co.uk/search","images.google.co.uk/images","search.aol.co.uk/web_uk.adp","www.ask.co.uk/res.asp","search.lycos.co.uk/cgi-bin/pursuit","search.freeserve.com/servlet/search/","images.google.com","groups.google.com","www.google.com/search","aolsearch.aol.com","search.aol.com","s.teoma.com/","www.hotbot.com","www.overture.com/d/search/p/altavista/","web.ask.com","pictures.ask.com","search.netscape.com");

	var engs=aEngines,nss=false;
		for(var i=engs.length-1;i>-1&&!nss;i--)
			nss=fromurl.match(engs[i])?fromurl:false;
				if(nss)
					{
					var im='<img src="http://adfarm.mediaplex.com/a'+'d/lt/4686-26260-10070-0?mpt=';
					im+=escape((new Date()).toGMTString())+'&mpcl=';
					im+=escape(visitedurl)+'&mpvl='+escape(nss)+'">';
					document.write(im);
					//alert("Hi");
					}
}

var page = "http://www.baazee.com/static/ProductsPopUpOtherPages.html";
var windowprops = "width=600,height=530,location=no,toolbar=no,menubar=no,scrollbars=no,resizable=no";

var bPopUpWindow=true;
function setPopOutSwitch(bOnOrOff,myfunction)
{bPopUpWindow=bOnOrOff;}

function GetCookie (name) {  
var arg = name + "=";  
var alen = arg.length;  
var clen = document.cookie.length;  
var i = 0;  
while (i < clen) {    
var j = i + alen;    
if (document.cookie.substring(i, j) == arg)      
return getCookieVal (j);    
i = document.cookie.indexOf(" ", i) + 1;    
if (i == 0) break;   
}  
return null;
}
function SetCookie (name, value) {  
var argv = SetCookie.arguments;  
var argc = SetCookie.arguments.length;  
var expires = (argc > 2) ? argv[2] : null;  
var path = "/";  
var domain = "www.baazee.com";   
var secure = (argc > 5) ? argv[5] : false;  
document.cookie = name + "=" + value + 
((expires == null) ? "" : ("; expires=" + expires.toGMTString())) + 
((path == null) ? "" : ("; path=" + path)) +  
((domain == null) ? "" : ("; domain=" + domain)) +    
((secure == true) ? "; secure" : "");
}
function DeleteCookie (name) {  
var exp = new Date();  
exp.setTime (exp.getTime() - 1);  
var cval = GetCookie (name);  
document.cookie = name + "=" + cval + "; expires=" + exp.toGMTString();
}
var exp = new Date(); 
exp.setTime(exp.getTime() + (expHours*60*60*1000));
function amt(){
var count = GetCookie('PopUpExit')
if(count == null) {
SetCookie('PopUpExit','1')
return 1
}
else {
var newcount = parseInt(count) + 1;
DeleteCookie('PopUpExit')
SetCookie('PopUpExit',newcount,exp)
return count
	 }
}
function getCookieVal(offset) {
var endstr = document.cookie.indexOf (";", offset);
if (endstr == -1)
endstr = document.cookie.length;
return unescape(document.cookie.substring(offset, endstr));
}

	var expC = new Date(); 
	expC.setTime(expC.getTime() + (expHours*60*60*1000));

function callLinkTrace(SourcePage,SourceBlock,SourceSubSection,categoryId,Trade_TradeId){
SetCookie('TraceCookie', "1", exp);
if (SourcePage=="null"){SourcePage=''}
if (SourceBlock=="null"){SourceBlock=''}
if (SourceSubSection=="null"){SourceSubSection=''}
if (categoryId=="null"){categoryId=''}
if (Trade_TradeId=="null"){Trade_TradeId=''}
var string = "SourcePage="+SourcePage+"&SourceSection="+SourceBlock+"&SourceSubSection="+SourceSubSection+"&categoryId="+categoryId+"&Trade_TradeId="+Trade_TradeId;
SetCookie('LinkTrace', string, exp);
}

	function callNewLinkTrace(SourcePage,SourceBlock,SourceSubSection,SourceCategoryId,categoryId){
		SetCookie('TraceCookie', "1", expC);
		if (SourcePage=="null"){SourcePage=''}
		if (SourceBlock=="null"){SourceBlock=''}
		if (SourceSubSection=="null"){SourceSubSection=''}
		if (categoryId=="null"){categoryId=''}
		var string = "SourcePage="+SourcePage+"&SourceSection="+SourceBlock+"&SourceSubSection="+SourceSubSection+"&SourceCategoryId="+SourceCategoryId+"&categoryId="+categoryId;
		SetCookie('naLinkTrace', string, expC);
	}

	function iplt(SourceSubSection){
		var cookieval = GetCookie('naLinkTrace');
		var crumbs = cookieval.split("&");
		var sp = crumbs[0];
		var spcrumbs = sp.split("=");
		var SourcePage = spcrumbs[1];

		var scategoryid = crumbs[3];
		var scategoryidcrumbs = scategoryid.split("=");
		var SourceCategoryId = scategoryidcrumbs[1];

		callNewLinkTrace(SourcePage,'IP',SourceSubSection,SourceCategoryId,'null');
	}
	
	/*
		Function:  lthd
		Purpose:   Function to trace clicks on Header Block
		Parameters:
			SourcePage
			SourceSubSection
	*/
	function lthd(SourcePage, SourceCategoryId, SourceSubSection) {
		callNewLinkTrace(SourcePage, 'H', SourceSubSection, SourceCategoryId, '');
	}
	
	/*
		Function:  ltcn
		Purpose:   Function to trace clicks on Navigation Block on Category Page
		Parameters:
			SourceCategoryId
			TargetCategoryId
	*/
	function ltnv(SourcePage, SourceCategoryId, TargetCategoryId) {
		callNewLinkTrace(SourcePage, 'NV', '', SourceCategoryId, TargetCategoryId);
	}

	
	/*
		Function:  lthn
		Purpose:   Function to trace clicks on Navigation Block on Home Page
		Parameters:
			TargetCategoryId
	*/
	function lthn(TargetCategoryId) {
		//alert("I am going to make entry for linktrace");
		callNewLinkTrace('C', 'N', '', '1', TargetCategoryId);
	}
	
	
	/*
		Function:  ltpb
		Purpose:   Function to trace clicks on Promotion Block
		Parameters:
			SourcePage
			SourceSubSection
			SourceCategoryId

	*/	
	function ltpb(SourcePage, SourceSubSection, SourceCategoryId) {
		callNewLinkTrace(SourcePage, 'PB', SourceSubSection, SourceCategoryId, '');
	}
	
	/*
		Function:  ltfv
		Purpose:   Function to trace clicks on Favourates
		Parameters:
			SourcePage
			SourceSubSection
	*/
	function ltfv(SourcePage, SourceCategoryId, SourceSubSection) {
		callNewLinkTrace(SourcePage, 'FV', SourceSubSection, SourceCategoryId, '');
	}


function checkBoss() {
var paidSearch = fromurl.match(/google/g);
	if (!paidSearch)
	{
		SetCookie('TraceCookie', "0", exp);
		var count = GetCookie('PopUpExit');
			if (count == null) {
			count=1;
			SetCookie('PopUpExit', count, exp);

				if(bPopUpWindow){
				myWindow=window.open(page, "", windowprops);
				self.focus();
				if (!myWindow.opener) myWindow.opener = self;
				}
	}
		else 
		{
		count++;
		}
	}
}