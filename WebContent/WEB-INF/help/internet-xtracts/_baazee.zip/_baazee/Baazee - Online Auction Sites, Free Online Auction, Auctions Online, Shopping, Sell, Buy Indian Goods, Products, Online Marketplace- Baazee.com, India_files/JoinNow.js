var	missinginfo = "";

function emailCheck(emailStr) {
var checkTLD=1;

var knownDomsPat=/^(com|net|org|edu|int|mil|gov|arpa|biz|aero|name|coop|info|pro|museum)$/;
var emailPat=/^(.+)@(.+)$/;
var specialChars="\\(\\)><@,;:\\\\\\\"\\.\\[\\]";

var validChars="\[^\\s" + specialChars + "\]";


var quotedUser="(\"[^\"]*\")";

var ipDomainPat=/^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/;

var atom=validChars + '+';


var word="(" + atom + "|" + quotedUser + ")";

// The following pattern describes the structure of the user

var userPat=new RegExp("^" + word + "(\\." + word + ")*$");

/* The following pattern describes the structure of a normal symbolic
domain, as opposed to ipDomainPat, shown above. */

var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");

/* Finally, let's start trying to figure out if the supplied address is valid. */

/* Begin with the coarse pattern to simply break up user@domain into
different pieces that are easy to analyze. */

var matchArray=emailStr.match(emailPat);

if (matchArray==null) {

/* Too many/few @'s or something; basically, this address doesn't
even fit the general mould of a valid e-mail address. */

alert("Email address seems incorrect (check @ and .'s)");
return false;
}
var user=matchArray[1];
var domain=matchArray[2];

// Start by checking that only basic ASCII characters are in the strings (0-127).

for (i=0; i<user.length; i++) {
if (user.charCodeAt(i)>127) {
alert("This username contains invalid characters.");
return false;
   }
}
for (i=0; i<domain.length; i++) {
if (domain.charCodeAt(i)>127) {
alert("Ths domain name contains invalid characters.");
return false;
   }
}

// See if "user" is valid 

if (user.match(userPat)==null) {

// user is not valid

alert("The username doesn't seem to be valid.");
return false;
}

/* if the e-mail address is at an IP address (as opposed to a symbolic
host name) make sure the IP address is valid. */

var IPArray=domain.match(ipDomainPat);
if (IPArray!=null) {

// this is an IP address

for (var i=1;i<=4;i++) {
if (IPArray[i]>255) {
alert("Destination IP address is invalid!");
return false;
   }
}
return true;
}

// Domain is symbolic name.  Check if it's valid.
 
var atomPat=new RegExp("^" + atom + "$");
var domArr=domain.split(".");
var len=domArr.length;
for (i=0;i<len;i++) {
if (domArr[i].search(atomPat)==-1) {
alert("The domain name does not seem to be valid.");
return false;
   }
}

/* domain name seems valid, but now make sure that it ends in a
known top-level domain (like com, edu, gov) or a two-letter word,
representing country (uk, nl), and that there's a hostname preceding 
the domain or country. */

if (checkTLD && domArr[domArr.length-1].length!=2 && 
domArr[domArr.length-1].search(knownDomsPat)==-1) {
alert("The address must end in a well-known domain or two letter " + "country.");
return false;
}

// Make sure there's a host name preceding the domain.

if (len<2) {
alert("This address is missing a hostname!");
return false;
}

// If we've gotten this far, everything's valid!
//return true;
}

function showsamestdcode(curIndex)
	{			
		var city = curIndex;  // points to city options array

		if(curIndex == 8900 || curIndex == 9000)
		{
			document.RegistrationForm.stdcode.selectedIndex=134;
		}
		else if(curIndex == 0)
		{
			document.RegistrationForm.stdcode.selectedIndex=0;
		}
		else
		{
			document.RegistrationForm.stdcode.selectedIndex=curIndex+1;
		}

	}	

// Full Registration Form Function Starts here
var lele = 0;
	function checkSubmitFullRegistration()

		{
			var	missinginfo = "";

			if(document.RegistrationForm.firstName.value=="")
				{
					missinginfo +="\nPlease enter your First Name";
				}
			
			if((document.RegistrationForm.lastName.value==""))
				{
					missinginfo +="\nPlease enter your Last Name";
				}


		var swear_words_arr=new Array(".com","baazee","dotcom","test",",","[","^","(",")","{","}","*","$","#","@","!","|","?","<",">",":","+","=","%","~","`","/",".");

		var swear_alert_arr=new Array();
		var swear_alert_count=0;

function reset_alert_count()
{
 swear_alert_count=0;
}

function wordFilter(form,fields)
{
	reset_alert_count();
	var compare_text;
	var fieldErrArr=new Array();
	var fieldErrIndex=0;
	for(var i=0; i<fields.length; i++)
	{
		eval('compare_text=document.' + form + '.' + fields[i] + '.value;');
		for(var j=0; j<swear_words_arr.length; j++)
		{
			for(var k=0; k<(compare_text.length); k++)
			{
				if(swear_words_arr[j]==compare_text.substring(k,(k+swear_words_arr[j].length)).toLowerCase())
				{
					swear_alert_arr[swear_alert_count]=compare_text.substring(k,(k+swear_words_arr[j].length));
					swear_alert_count++;
					fieldErrArr[fieldErrIndex]=i;
					fieldErrIndex++;
				}
			}
		}
	}
	var alert_text="";
	for(var k=1; k<=swear_alert_count; k++)
	{
		alert_text+=swear_alert_arr[k-1];
	}
	if(swear_alert_count>0)
	{
		lele = 1;
		missinginfo +="\n'"+alert_text+"' is invalid character in Baazee ID";
		return false;
	}
	else
	{
		lele = 0;
		return true;
	}
}
			
			wordFilter('RegistrationForm',['alias']);




			if((document.RegistrationForm.emailAddress.value==""))
				{
					missinginfo +="\nPlease enter your Email ID";
				}
					else
					{

				if(emailCheck(document.RegistrationForm.emailAddress.value)==false){
					missinginfo +="\nPlease enter your Email ID";
				}
				

				
					if(document.RegistrationForm.emailAddress.value != document.RegistrationForm.emailAddressConfirm.value)
						{
						missinginfo +="\nYour Email ID entries do not match. Please check your Email ID";
						}
				}

	
							if((document.RegistrationForm.alias.value==""))
				{
					missinginfo +="\nPlease enter your Baazee ID";
				}
				else if ((document.RegistrationForm.alias.value!=""))
				{
					if (lele!=1){
					if ((document.RegistrationForm.alias.value.length < 5)||(document.RegistrationForm.alias.value.length > 20))
					{
						missinginfo +="\nBaazee ID should be a minimum 5 characters";
					}
					}
				}
			


				if((document.RegistrationForm.userPassword.value==""))
				{
					missinginfo +="\nPlease enter your Password";
				}
				else
				{

					if(document.RegistrationForm.userPassword.value != document.RegistrationForm.confirmPassword.value)
					{
					missinginfo +="\nYour Password entries do not match. Please check your Password";
					}

				}
			if((document.RegistrationForm.day_of_birth.options[document.RegistrationForm.day_of_birth.selectedIndex].value=="-1")||(document.RegistrationForm.month_of_birth.options[document.RegistrationForm.month_of_birth.selectedIndex].value=="-1")||(document.RegistrationForm.year_of_birth.options[document.RegistrationForm.year_of_birth.selectedIndex].value=="-1"))
				{
					missinginfo +="\nPlease provide your Date of Birth";
				}
			
			if((document.RegistrationForm.address1.value==""))
				{
					missinginfo +="\nPlease enter your Address Line 1";
				}
			
			if((document.RegistrationForm.address2.value==""))
				{
					missinginfo +="\nPlease enter your Address Line 2";
				}

			if((document.RegistrationForm.address3.value==""))
				{
					missinginfo +="\nPlease enter your Address Line 3";
				}
			if((document.RegistrationForm.country.options[document.RegistrationForm.country.selectedIndex].value=="-1"))
				{
					missinginfo +="\nPlease select your Country";
				}
		
			if((document.RegistrationForm.location.options[document.RegistrationForm.location.selectedIndex].value=="-1"))
				{
					missinginfo +="\nPlease select your City";
				}

			if((document.RegistrationForm.zipCode.value==""))
				{
					missinginfo +="\nPlease select your Postal / Zip code";
				}

			if((document.RegistrationForm.preferredcontactoption.options[document.RegistrationForm.preferredcontactoption.selectedIndex].value==""))
				{
					missinginfo +="\nPlease enter your Contact Time";
				}

			if((document.RegistrationForm.stdcode.options[document.RegistrationForm.stdcode.selectedIndex].value=="-1"))
				{
					missinginfo +="\nPlease enter your Std Code";
				}

			if((document.RegistrationForm.telephone1.value=="")&&(document.RegistrationForm.telephone1.value==""))
				{
					missinginfo +="\nPlease enter Day Telephone No.";
				}
			if((document.RegistrationForm.telephone2.value=="")&&(document.RegistrationForm.telephone2.value==""))
				{
					missinginfo +="\nPlease enter Evening Telephone No.";
				}

			if (missinginfo != "") 
				{
					alert(missinginfo);
					return false;
				}
			else
				{
					//document.RegistrationForm.submit();
					disableForm(document.RegistrationForm);
					return true;
				}
		}

// Half Registration Form Function Starts here
		
	function checkSubmitHalfRegistration()

		{
			var	missinginfo = "";

			if((document.RegistrationForm.address1.value==""))
				{
					missinginfo +="\nPlease enter your Address Line 1";
				}
			
			if((document.RegistrationForm.address2.value==""))
				{
					missinginfo +="\nPlease enter your Address Line 2";
				}

			if((document.RegistrationForm.address3.value==""))
				{
					missinginfo +="\nPlease enter your Address Line 3";
				}
			if((document.RegistrationForm.country.options[document.RegistrationForm.country.selectedIndex].value=="-1"))
				{
					missinginfo +="\nPlease select your Country";
				}
		
			if((document.RegistrationForm.location.options[document.RegistrationForm.location.selectedIndex].value=="-1"))
				{
					missinginfo +="\nPlease select your City";
				}

			if((document.RegistrationForm.zipCode.value==""))
				{
					missinginfo +="\nPlease select your Postal / Zip code";
				}

			if((document.RegistrationForm.preferredcontactoption.options[document.RegistrationForm.preferredcontactoption.selectedIndex].value==""))
				{
					missinginfo +="\nPlease enter your Contact Time";
				}

			if((document.RegistrationForm.stdcode.options[document.RegistrationForm.stdcode.selectedIndex].value=="-1"))
				{
					missinginfo +="\nPlease enter your Std Code";
				}

			if((document.RegistrationForm.telephone1.value=="")&&(document.RegistrationForm.telephone1.value==""))
				{
					missinginfo +="\nPlease enter Day Telephone No.";
				}
			if((document.RegistrationForm.telephone2.value=="")&&(document.RegistrationForm.telephone2.value==""))
				{
					missinginfo +="\nPlease enter Evening Telephone No.";
				}

			if (missinginfo != "") 
				{
					alert(missinginfo);
					return false;
				}
			else
				{
					//document.RegistrationForm.submit();
					disableForm(document.RegistrationForm);
					return true;
				}
		}



// Partial Registration Form Function Starts here

	function checkSubmitPartialRegistration()

		{
			var	missinginfo = "";

			if(document.RegistrationForm.firstName.value=="")
				{
					missinginfo +="\nPlease enter your First Name";
				}
			
			if((document.RegistrationForm.lastName.value==""))
				{
					missinginfo +="\nPlease enter your Last Name";
				}


		var swear_words_arr=new Array(".com","baazee","dotcom","test",",","[","^","(",")","{","}","*","$","#","@","!","|","?","<",">",":","+","=","%","~","`","/",".");

		var swear_alert_arr=new Array();
		var swear_alert_count=0;

function reset_alert_count()
{
 swear_alert_count=0;
}

function wordFilter(form,fields)
{
	reset_alert_count();
	var compare_text;
	var fieldErrArr=new Array();
	var fieldErrIndex=0;
	for(var i=0; i<fields.length; i++)
	{
		eval('compare_text=document.' + form + '.' + fields[i] + '.value;');
		for(var j=0; j<swear_words_arr.length; j++)
		{
			for(var k=0; k<(compare_text.length); k++)
			{
				if(swear_words_arr[j]==compare_text.substring(k,(k+swear_words_arr[j].length)).toLowerCase())
				{
					swear_alert_arr[swear_alert_count]=compare_text.substring(k,(k+swear_words_arr[j].length));
					swear_alert_count++;
					fieldErrArr[fieldErrIndex]=i;
					fieldErrIndex++;
				}
			}
		}
	}
	var alert_text="";
	for(var k=1; k<=swear_alert_count; k++)
	{
		alert_text+=swear_alert_arr[k-1];
	}
	if(swear_alert_count>0)
	{
		lele = 1;
		missinginfo +="\n'"+alert_text+"' is invalid character in Baazee ID";
		return false;
	}
	else
	{
		lele = 0;
		return true;
	}
}
			
			wordFilter('RegistrationForm',['alias']);




			if((document.RegistrationForm.emailAddress.value==""))
				{
					missinginfo +="\nPlease enter your Email ID";
				}
					else
					{

				if(emailCheck(document.RegistrationForm.emailAddress.value)==false){
					missinginfo +="\nPlease enter your Email ID";
				}
				

				
					if(document.RegistrationForm.emailAddress.value != document.RegistrationForm.emailAddressConfirm.value)
						{
						missinginfo +="\nYour Email ID entries do not match. Please check your Email ID";
						}
				}

	
							if((document.RegistrationForm.alias.value==""))
				{
					missinginfo +="\nPlease enter your Baazee ID";
				}
				else if ((document.RegistrationForm.alias.value!=""))
				{
					if (lele!=1){
					if ((document.RegistrationForm.alias.value.length < 5)||(document.RegistrationForm.alias.value.length > 20))
					{
						missinginfo +="\nBaazee ID should be a minimum 5 characters";
					}
					}
				}
			


				if((document.RegistrationForm.userPassword.value==""))
				{
					missinginfo +="\nPlease enter your Password";
				}
					else
					{

						if(document.RegistrationForm.userPassword.value != document.RegistrationForm.confirmPassword.value)
						{
						missinginfo +="\nYour Password entries do not match. Please check your Password";
						}

				}
				
			if((document.RegistrationForm.day_of_birth.options[document.RegistrationForm.day_of_birth.selectedIndex].value=="-1")||(document.RegistrationForm.month_of_birth.options[document.RegistrationForm.month_of_birth.selectedIndex].value=="-1")||(document.RegistrationForm.year_of_birth.options[document.RegistrationForm.year_of_birth.selectedIndex].value=="-1"))
				{
					missinginfo +="\nPlease provide your Date of Birth";
				}

			if (missinginfo != "") 
				{
					alert(missinginfo);
					return false;
				}
			else
				{
					//document.RegistrationForm.submit();
					disableForm(document.RegistrationForm);
					return true;
				}
		}



// Update Partial Registration Form Function Starts here

	function checkSubmitUpdatePartial()

		{
			var	missinginfo = "";

			if(document.RegistrationForm.firstName.value=="")
				{
					missinginfo +="\nPlease enter your First Name";
				}
			
			if((document.RegistrationForm.lastName.value==""))
				{
					missinginfo +="\nPlease enter your Last Name";
				}


		var swear_words_arr=new Array(".com","baazee","dotcom","test",",","[","^","(",")","{","}","*","$","#","@","!","|","?","<",">",":","+","=","%","~","`","/",".");

		var swear_alert_arr=new Array();
		var swear_alert_count=0;

function reset_alert_count()
{
 swear_alert_count=0;
}

function wordFilter(form,fields)
{
	reset_alert_count();
	var compare_text;
	var fieldErrArr=new Array();
	var fieldErrIndex=0;
	for(var i=0; i<fields.length; i++)
	{
		eval('compare_text=document.' + form + '.' + fields[i] + '.value;');
		for(var j=0; j<swear_words_arr.length; j++)
		{
			for(var k=0; k<(compare_text.length); k++)
			{
				if(swear_words_arr[j]==compare_text.substring(k,(k+swear_words_arr[j].length)).toLowerCase())
				{
					swear_alert_arr[swear_alert_count]=compare_text.substring(k,(k+swear_words_arr[j].length));
					swear_alert_count++;
					fieldErrArr[fieldErrIndex]=i;
					fieldErrIndex++;
				}
			}
		}
	}
	var alert_text="";
	for(var k=1; k<=swear_alert_count; k++)
	{
		alert_text+=swear_alert_arr[k-1];
	}
	if(swear_alert_count>0)
	{
		lele = 1;
		missinginfo +="\n'"+alert_text+"' is invalid character in Baazee ID";
		return false;
	}
	else
	{
		lele = 0;
		return true;
	}
}
			
			wordFilter('RegistrationForm',['alias']);


			if((document.RegistrationForm.emailAddress.value==""))
				{
					missinginfo +="\nPlease enter your Email ID";
				}
					else
					{

				if(emailCheck(document.RegistrationForm.emailAddress.value)==false){
					missinginfo +="\nPlease enter your Email ID";
				}
				

				
					if(document.RegistrationForm.emailAddress.value != document.RegistrationForm.emailAddressConfirm.value)
						{
						missinginfo +="\nYour Email ID entries do not match. Please check your Email ID";
						}
				}

	
							if((document.RegistrationForm.alias.value==""))
				{
					missinginfo +="\nPlease enter your Baazee ID";
				}
				else if ((document.RegistrationForm.alias.value!=""))
				{
					if (lele!=1){
					if ((document.RegistrationForm.alias.value.length < 5)||(document.RegistrationForm.alias.value.length > 20))
					{
						missinginfo +="\nBaazee ID should be a minimum 5 characters";
					}
					}
				}
			
				if((document.RegistrationForm.day_of_birth.options[document.RegistrationForm.day_of_birth.selectedIndex].value=="-1")||(document.RegistrationForm.month_of_birth.options[document.RegistrationForm.month_of_birth.selectedIndex].value=="-1")||(document.RegistrationForm.year_of_birth.options[document.RegistrationForm.year_of_birth.selectedIndex].value=="-1"))
				{
					missinginfo +="\nPlease provide your Date of Birth";
				}

			if (missinginfo != "") 
				{
					alert(missinginfo);
					return false;
				}
			else
				{
					//document.RegistrationForm.submit();
					disableForm(document.RegistrationForm);
					return true;
				}
		}



// Update Full Registration Form Function Starts here

	function checkSubmitUpdateFull()

		{
			var	missinginfo = "";

			if(document.RegistrationForm.firstName.value=="")
				{
					missinginfo +="\nPlease enter your First Name";
				}
			
			if((document.RegistrationForm.lastName.value==""))
				{
					missinginfo +="\nPlease enter your Last Name";
				}


		var swear_words_arr=new Array(".com","baazee","dotcom","test",",","[","^","(",")","{","}","*","$","#","@","!","|","?","<",">",":","+","=","%","~","`","/",".");

		var swear_alert_arr=new Array();
		var swear_alert_count=0;

function reset_alert_count()
{
 swear_alert_count=0;
}

function wordFilter(form,fields)
{
	reset_alert_count();
	var compare_text;
	var fieldErrArr=new Array();
	var fieldErrIndex=0;
	for(var i=0; i<fields.length; i++)
	{
		eval('compare_text=document.' + form + '.' + fields[i] + '.value;');
		for(var j=0; j<swear_words_arr.length; j++)
		{
			for(var k=0; k<(compare_text.length); k++)
			{
				if(swear_words_arr[j]==compare_text.substring(k,(k+swear_words_arr[j].length)).toLowerCase())
				{
					swear_alert_arr[swear_alert_count]=compare_text.substring(k,(k+swear_words_arr[j].length));
					swear_alert_count++;
					fieldErrArr[fieldErrIndex]=i;
					fieldErrIndex++;
				}
			}
		}
	}
	var alert_text="";
	for(var k=1; k<=swear_alert_count; k++)
	{
		alert_text+=swear_alert_arr[k-1];
	}
	if(swear_alert_count>0)
	{
		lele = 1;
		missinginfo +="\n'"+alert_text+"' is invalid character in Baazee ID";
		return false;
	}
	else
	{
		lele = 0;
		return true;
	}
}
			
			wordFilter('RegistrationForm',['alias']);


		
							if((document.RegistrationForm.alias.value==""))
				{
					missinginfo +="\nPlease enter your Baazee ID";
				}
				else if ((document.RegistrationForm.alias.value!=""))
				{
					if (lele!=1){
					if ((document.RegistrationForm.alias.value.length < 5)||(document.RegistrationForm.alias.value.length > 20))
					{
						missinginfo +="\nBaazee ID should be a minimum 5 characters";
					}
					}
				}
			
			if((document.RegistrationForm.day_of_birth.options[document.RegistrationForm.day_of_birth.selectedIndex].value=="-1")||(document.RegistrationForm.month_of_birth.options[document.RegistrationForm.month_of_birth.selectedIndex].value=="-1")||(document.RegistrationForm.year_of_birth.options[document.RegistrationForm.year_of_birth.selectedIndex].value=="-1"))
				{
					missinginfo +="\nPlease provide your Date of Birth";
				}

			if((document.RegistrationForm.address1.value==""))
				{
					missinginfo +="\nPlease enter your Address Line 1";
				}
			
			if((document.RegistrationForm.address2.value==""))
				{
					missinginfo +="\nPlease enter your Address Line 2";
				}

			if((document.RegistrationForm.address3.value==""))
				{
					missinginfo +="\nPlease enter your Address Line 3";
				}
			if((document.RegistrationForm.country.options[document.RegistrationForm.country.selectedIndex].value=="-1"))
				{
					missinginfo +="\nPlease select your Country";
				}
		
			if((document.RegistrationForm.location.options[document.RegistrationForm.location.selectedIndex].value=="-1"))
				{
					missinginfo +="\nPlease select your City";
				}

			if((document.RegistrationForm.zipCode.value==""))
				{
					missinginfo +="\nPlease select your Postal / Zip code";
				}

			if((document.RegistrationForm.preferredcontactoption.options[document.RegistrationForm.preferredcontactoption.selectedIndex].value==""))
				{
					missinginfo +="\nPlease enter your Contact Time";
				}

			if((document.RegistrationForm.stdcode.options[document.RegistrationForm.stdcode.selectedIndex].value=="-1"))
				{
					missinginfo +="\nPlease enter your Std Code";
				}

			if((document.RegistrationForm.telephone1.value=="")&&(document.RegistrationForm.telephone1.value==""))
				{
					missinginfo +="\nPlease enter Day Telephone No.";
				}
			if((document.RegistrationForm.telephone2.value=="")&&(document.RegistrationForm.telephone2.value==""))
				{
					missinginfo +="\nPlease enter Evening Telephone No.";
				}

			if (missinginfo != "") 
				{
					alert(missinginfo);
					return false;
				}
			else
				{
					//document.RegistrationForm.submit();
					disableForm(document.RegistrationForm);
					return true;
				}
		}

// Change Email Form Function Starts here

	function checkSubmitChangeEmail()

		{
			var	missinginfo = "";

			if((document.ChangeEmailID.oldemailAddress.value==""))
				{
					missinginfo +="\nPlease enter your Old Email ID";
				}
			

			if((document.ChangeEmailID.emailAddress.value==""))
				{
					missinginfo +="\nPlease enter your Email ID";
				}
				else
				{
					if(emailCheck(document.RegistrationForm.emailAddress.value)==false){
					missinginfo +="\nPlease enter your Email ID";
				}
				}
	
				

			if (missinginfo != "") 
				{
					alert(missinginfo);
					return false;
				}
			else
				{
					//document.ChangeEmailID.submit();
					document.ChangeEmailID.ChangeEmail.disabled=true;
					return true;
				}
		

		}



// Forgot Password Form Function Starts here

	function checkSubmitForgotPassword()

		{
			var	missinginfo = "";

			if((document.ChangePassword.emailaddress.value==""))
				{
					missinginfo +="\nPlease enter your Email ID";
				}
			else
			    {

				//return emailCheck (document.ChangePassword.emailaddress.value);
				if(emailCheck(document.ChangePassword.emailaddress.value) == false){
					missinginfo +="\nPlease enter your Email ID";
				 }
					
				}
			if((document.ChangePassword.day_of_birth.options[document.ChangePassword.day_of_birth.selectedIndex].value=="-1")||(document.ChangePassword.month_of_birth.options[document.ChangePassword.month_of_birth.selectedIndex].value=="-1")||(document.ChangePassword.year_of_birth.options[document.ChangePassword.year_of_birth.selectedIndex].value=="-1"))
			{
				missinginfo +="\nPlease provide your Date of Birth";
			}

			if (missinginfo != "") 
				{
					alert(missinginfo);
					return false;
				}
			else
				{
					//document.ChangePassword.submit();
					document.ChangePassword.MailPassword.disabled=true;
					return true;
				}
		

		}


// Change Password Form Function Starts here


	function checkSubmitChangePassword()

		{
			var	missinginfo = "";

				if((document.ChangePassword.oldPassword.value==""))
				{
					missinginfo +="\nPlease enter your Old Password";
				}


				if((document.ChangePassword.userPassword.value==""))
				{
					missinginfo +="\nPlease enter your Password";
				}
					else
					{

						if(document.ChangePassword.userPassword.value != document.ChangePassword.userPasswordVerify.value)
						{
						missinginfo +="\nRe-type New Password. Your password entries do not match";
						}

				}


			if (missinginfo != "") 
				{
					alert(missinginfo);
					return false;
				}
			else
				{
					//document.ChangePassword.submit();
					document.ChangePassword.passwordButton.disabled=true;
					return true;
				}
		}



	function disableForm(theform)
		{
			if (document.all || document.getElementById)
				{
					for (i = 0; i < theform.length; i++)
				{
					var tempobj = theform.elements[i];
					if (tempobj.type.toLowerCase() == "submit" || tempobj.type.toLowerCase() == "button")
					tempobj.disabled = true;
				}
					return true;
				}
			else
				{
					alert("The form has been submitted.But, since you're not using IE 4+ or NS 6, the submit button was not disabled on form submission.");
					return false;
				}
		}